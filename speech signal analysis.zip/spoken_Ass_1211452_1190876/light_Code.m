% Read the 'Li' and 'Ight' segments
[li_dta, li_Fs] = audioread('Li.wav');
[ight_dta, ight_Fs] = audioread('Ight.wav');
%sampling rates match:
assert(li_Fs == ight_Fs, 'Sampling rates must match!');
Fs = li_Fs;
% Normalize audio segments to prevent clipping:
li_dta = li_dta / max(abs(li_dta));
ight_dta = ight_dta / max(abs(ight_dta));

% Create crossfade
overlap_length = round(0.02 * Fs); % 20 milliseconds overlap
fade_out = linspace(1, 0, overlap_length)';
fade_in = linspace(0, 1, overlap_length)';
% Apply crossfade
li_end = li_dta(end-overlap_length+1:end) .* fade_out;
ight_start = ight_dta(1:overlap_length) .* fade_in;

% Combine the segments
light_combined = [li_dta(1:end-overlap_length); li_end + ight_start; ight_dta(overlap_length+1:end)];

% Normalize the final combined audio to prevent clipping
light_combined = light_combined / max(abs(light_combined));

% Save the audio with higher quality settings
audiowrite('light_high_quality.wav', light_combined, Fs, 'BitsPerSample', 24);
% Optional: Play the sound
sound(light_combined, Fs);